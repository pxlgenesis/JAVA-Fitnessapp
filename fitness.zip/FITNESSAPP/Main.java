package com.fitnessapp;

import com.fitnessapp.diet.Diet;
import com.fitnessapp.workout.Workout;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static List<Diet> diets = new ArrayList<>();
    private static List<Workout> workouts = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String choice;

        do {
            System.out.println("\n1. Add diet");
            System.out.println("2. Delete diet");
            System.out.println("3. Add workout");
            System.out.println("4. Delete workout");
            System.out.println("5. View diets and workouts");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    addDiet(scanner);
                    break;
                case "2":
                    deleteDiet(scanner);
                    break;
                case "3":
                    addWorkout(scanner);
                    break;
                case "4":
                    deleteWorkout(scanner);
                    break;
                case "5":
                    viewDietsAndWorkouts();
                    break;
                case "6":
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (!choice.equals("6"));
    }

    private static void addDiet(Scanner scanner) {
        System.out.print("Enter diet name: ");
        String name = scanner.nextLine();
        System.out.print("Enter protein: ");
        int protein = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter calories: ");
        int calories = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter carbs: ");
        int carbs = Integer.parseInt(scanner.nextLine());

        diets.add(new Diet(name, protein, calories, carbs));
        System.out.println("Diet added successfully!");
	System.out.println("-------------------------------------------");
    }

    private static void deleteDiet(Scanner scanner) {
        System.out.print("Enter diet name to delete: ");
        String name = scanner.nextLine();

        diets.removeIf(diet -> diet.getName().equals(name));
        System.out.println("Diet deleted successfully!");
	System.out.println("-------------------------------------------");
    }

    private static void addWorkout(Scanner scanner) {
        System.out.print("Enter workout name: ");
        String name = scanner.nextLine();
        System.out.print("Enter length(min): ");
        int length = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter muscle: ");
        String muscle = scanner.nextLine();
        System.out.print("Enter type (compound or isolation): ");
        String type = scanner.nextLine();

        workouts.add(new Workout(name, length, muscle, type));
        System.out.println("Workout added successfully!");
	System.out.println("-------------------------------------------");
    }

    private static void deleteWorkout(Scanner scanner) {
        System.out.print("Enter workout name to delete: ");
        String name = scanner.nextLine();

        workouts.removeIf(workout -> workout.getName().equals(name));
        System.out.println("Workout deleted successfully!");
	System.out.println("-------------------------------------------");
    }

    private static void viewDietsAndWorkouts() {
        System.out.println("\nDiets:");
        for (Diet diet : diets) {
	    System.out.println("-------------------------------------------");
            System.out.println("Diet Name: " + diet.getName());
            System.out.println("Protein: " + diet.getProtein() + "g");
            System.out.println("Calories: " + diet.getCalories()+ "kj");
            System.out.println("Carbs: " + diet.getCarbs()+ "g");
	    System.out.println("-------------------------------------------");
            System.out.println();
        }

        System.out.println("Workouts:");
        for (Workout workout : workouts) {
	    System.out.println("-------------------------------------------");
            System.out.println("Workout Name: " + workout.getName());
            System.out.println("Length: " + workout.getLength()+ " min");
            System.out.println("Muscle: " + workout.getMuscle());
            System.out.println("Type: " + workout.getType());
            System.out.println("-------------------------------------------");
        }
    }
}

