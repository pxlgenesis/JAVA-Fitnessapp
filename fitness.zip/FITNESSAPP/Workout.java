package com.fitnessapp.workout;

public class Workout extends Activity {
    private String muscle;
    private String type; // compound or isolation

    public Workout(String name, int length, String muscle, String type) {
        super(name, length);
        this.muscle = muscle;
        this.type = type;
    }

    // Implement the methods from the Activity abstract class
    public String getMuscle() {
        return this.muscle;
    }

    public String getType() {
        return this.type;
    }
}
