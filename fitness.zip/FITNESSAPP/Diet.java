package com.fitnessapp.diet;

public class Diet implements Nutrition {
    private String name;
    private int protein;
    private int calories;
    private int carbs;

    public Diet(String name, int protein, int calories, int carbs) {
        this.name = name;
        this.protein = protein;
        this.calories = calories;
        this.carbs = carbs;
    }

    // Implement the methods from the Nutrition interface
    public String getName() {
        return this.name;
    }

    public int getProtein() {
        return this.protein;
    }

    public int getCalories() {
        return this.calories;
    }

    public int getCarbs() {
        return this.carbs;
    }
}
