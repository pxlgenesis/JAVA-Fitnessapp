package com.fitnessapp.diet;

public interface Nutrition {
    String getName();
    int getProtein();
    int getCalories();
    int getCarbs();
}
