package com.fitnessapp.workout;

public abstract class Activity {
    private String name;
    private int length;

    public Activity(String name, int length) {
        this.name = name;
        this.length = length;
    }

    public String getName() {
        return this.name;
    }

    public int getLength() {
        return this.length;
    }

    public abstract String getMuscle();
    public abstract String getType();

    // setters for name and length
}
